<div id="carouselExample" class="carousel slide" data-bs-ride="carousel" data-bs-interval="2000">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://sustentavel.com.br/wp-content/uploads/2018/07/composto.jpg" class="d-block w-100 img-fluid" alt="...">
        </div>
        <div class="carousel-item">
            <img src="https://storage.kupi.cz/d/magazine-article/17932/large" class="d-block w-100 img-fluid" alt="...">
        </div>
        <div class="carousel-item">
            <img src="https://fundacioncarlosslim.org/wp-content/uploads/2020/11/composta-1.jpg" class="d-block w-100 img-fluid" alt="...">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
