<div id="carrusel12" class="carousel slide" data-bs-ride="carousel" >
    <h3>Publicaciones</h3>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7kp3hxkH5Pn0C609ZrKVFUQXCLTXRAPb2ACdJB-o6tQ&s" class="d-block mx-auto" alt="Imagen1" style="max-width: 100%;" width="450px"; height="100%">
        </div>
        <div class="carousel-item">
            <img src="https://image.isu.pub/151026035220-1619de08c9fdc988ecffc89f5f99111f/jpg/page_1_thumb_large.jpg" class="d-block mx-auto" alt="Imagen2" style="max-width: 80%;" width="450px"; height="100%">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carrusel12" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carrusel12" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>