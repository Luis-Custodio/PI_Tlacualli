<div id="carrusel1" class="carousel slide" data-bs-ride="carousel">
    <h3>Promociones</h3>
    <div class="carousel-inner">
        <div class="carousel-item active">

            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRd1TV6F79DQaHvrNU60Dx1ansavn0RcZq4FJsyNP_4OQ&s" class="d-block mx-auto" alt="Imagen1">
            
        </div>
        <div class="carousel-item">

            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS11Qfc8mUT-U1lG3dE4FNrwlLNQF80b5j5Q9Pi6x_ulw&s" class="d-block mx-auto" alt="Imagen2">
        </div>
        <div class="carousel-item">
            <img src="https://m.media-amazon.com/images/I/41SfgXVxoQL._AC_.jpg" class="d-block mx-auto" alt="Imagen3">

        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carrusel1" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carrusel1" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

