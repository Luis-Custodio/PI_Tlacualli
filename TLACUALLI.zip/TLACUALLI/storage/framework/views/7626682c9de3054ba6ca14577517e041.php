<div class="contentItemsCarrusel">
      <div class="itemCarrusel" id="itemCarrusel-1">
        <section class="position-relative py-10 py-sm-12" style="background-image:url(https://sustentavel.com.br/wp-content/uploads/2018/07/composto.jpg); background-position: center left; background-size: cover; height:100%;">
          <div class="bg-overlay bg-dark opacity-2"></div>
          <div class="container z-index-9 position-relative">
              <div class="row">
                  <div class="col-xl-8 m-auto text-center py-xl-8">
                      <h1 class="display-4 text-white mb-3 mt-5">Únete a nuestra comunidad TLACUALLI</h1>
                      <h5 class="text-white mb-3">Somos una comunidad que permite la vinculación de administraciones restauranteras con agrupaciones encargadas del tratamiento de residuos orgánicos para la producción de composta y productos derivados.</h5>
                      <a href="#" class="btn btn-lg btn-success mb-0 mb-5">Descubre Más</a>
                  </div>
              </div> 
          </div>
      </section>
        <div class="flechaCarrusel">
          <a href="#itemCarrusel-5">
            <i class="bi bi-caret-left"></i>
          </a>
          <a href="#itemCarrusel-2">
            <i class="bi bi-caret-right"></i>
          </a>
        </div>
      </div>
      <div class="itemCarrusel" id="itemCarrusel-2">
          <span><img src="https://concytep.gob.mx/wp-content/uploads/2024/02/banner_becas_tesis-scaled.jpg" alt="..."></span>
        <div class="flechaCarrusel">
          <a href="#itemCarrusel-1">
            <i class="bi bi-caret-left"></i>
          </a>
          <a href="#itemCarrusel-3">
            <i class="bi bi-caret-right"></i>
          </a>
        </div>
      </div>
      <div class="itemCarrusel" id="itemCarrusel-3">
          <span><img src="https://www.ull.es/portal/agenda/wp-content/uploads/sites/12/2022/09/Campustajes_Banner-eventos-nuevo.png" alt="..."></span>
        <div class="flechaCarrusel">
          <a href="#itemCarrusel-2">
            <i class="bi bi-caret-left"></i>
          </a>
          <a href="#itemCarrusel-4">
            <i class="bi bi-caret-right"></i>
          </a>
        </div>
      </div>
      <div class="itemCarrusel" id="itemCarrusel-4">
          <span><img src="https://movimientociudadano.mx/storage/news/300420_mcj_postlink_huertourbanocoronavirus_1.banner.png" alt="..."></span>
        <div class="flechaCarrusel">
          <a href="#itemCarrusel-3">
            <i class="bi bi-caret-left"></i>
          </a>
          <a href="#itemCarrusel-5">
            <i class="bi bi-caret-right"></i>
          </a>
        </div>
      </div>
      <div class="itemCarrusel" id="itemCarrusel-5">
          <span><img src="https://home-statics.boletia.com/uploads/event/banner/118190/BannerBoletia_Ecofest2017.png" alt="..."></span>
        <div class="flechaCarrusel">
          <a href="#itemCarrusel-4">
            <i class="bi bi-caret-left"></i>
          </a>
          <a href="#itemCarrusel-1">
            <i class="bi bi-caret-right"></i>
          </a>
        </div>
      </div>
    </div>
    <div id=contentPuntos>
    <a href="#itemCarrusel-1">°</a>
    <a href="#itemCarrusel-2">°</a>
    <a href="#itemCarrusel-3">°</a>
    <a href="#itemCarrusel-4">°</a>
    <a href="#itemCarrusel-5">°</a>
    </div><?php /**PATH C:\GitHub\PI_Tlacualli\TLACUALLI\resources\views/partials/carrusel_home.blade.php ENDPATH**/ ?>